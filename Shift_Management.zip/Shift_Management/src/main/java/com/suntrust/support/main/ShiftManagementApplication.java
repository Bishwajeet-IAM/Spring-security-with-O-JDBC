package com.suntrust.support.main;

import java.util.concurrent.TimeUnit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.CacheControl;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;



@SpringBootApplication
@EnableWebMvc
@Configuration
@EnableAutoConfiguration
//@EnableAspectJAutoProxy (proxyTargetClass=true)
@ComponentScan ({"com.suntrust.support.model","com.suntrust.support.controller","com.suntrust.support.dao","com.suntrust.support.security"})
public class ShiftManagementApplication implements WebMvcConfigurer{

	public static void main(String[] args) {
		SpringApplication.run(ShiftManagementApplication.class, args);
	}
	  

		 @Override
		    public void addResourceHandlers(ResourceHandlerRegistry registry) {

		        // Register resource handler for images
		        registry.addResourceHandler("/images/**").addResourceLocations("/WEB-INF/images/")
		                .setCacheControl(CacheControl.maxAge(2, TimeUnit.HOURS).cachePublic());
		    }
}

