package com.suntrust.support.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement
@Entity
@Table(name = "SHIFT_EMP")
public class emp implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	
	@Column(name = "RACF_ID")
	private String racfid;
	@Column(name = "NAME")
	private String name;
	@Column(name = "EMAIL")
	private String email;
	@Column(name = "PASSWORD")
	private String password;
	@Column(name = "PH")
	private String ph;
	@Column(name = "STATUS")
	private String en;
	@Column(name = "ROLE")
	private String role;
	
	/*
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "SHIFT_EMP_ROLE", joinColumns = @JoinColumn(name = "RACF_ID"), inverseJoinColumns = @JoinColumn(name = "ROLE_ID"))
	private Set<role> roles;*/
	
	
	public String getRacfid() {
		return racfid;
	}

	public void setRacfid(String racfid) {
		this.racfid = racfid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPh() {
		return ph;
	}

	public void setPh(String ph) {
		this.ph = ph;
	}

	public String getEn() {
		return en;
	}

	public void setEn(String en) {
		this.en = en;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	/*public Set<role> getRoles() {
		return roles;
	}

	public void setRoles(Set<role> roles) {
		this.roles = roles;
	}*/

	public emp(){}
	
	public emp(String r, String n,String e,String p,String ph,String en,String rol) {

		this.racfid=r;
		this.name=n;
		this.email=e;
		this.password=p;
		this.ph=ph;
		this.en=en;
		this.role=rol;
	}
	
	  @Override
	    public String toString() {
	        return String.format(
"EMPLOYEE Details->[RACF ID='%s',NAME='%s',EMAIL='%s',pASSWORD= '%s',PHONE='%s',ROLE ='%s'",
racfid,name,email,password,ph,role);
	    }

}

