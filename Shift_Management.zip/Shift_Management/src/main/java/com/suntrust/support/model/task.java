package com.suntrust.support.model;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class task implements Serializable {

	
	private String taskid,assignedby,assignee,status,details,update,createdate,enddate,priority,app,intassignee,time,env;
	
	//Getter and setter methods 
 
	public String getEnv() {
		return env;
	}

	public void setEnv(String env) {
		this.env = env;
	}

	public String getIntassignee() {
		return intassignee;
	}

	public void setIntassignee(String intassignee) {
		this.intassignee = intassignee;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

		public String getEnddate() {
		return enddate;
	}

	public void setEnddate(String enddate) {
		this.enddate = enddate;
	}

		public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public String getApp() {
		return app;
	}

	public void setApp(String app) {
		this.app = app;
	}

		public String getTaskid() {
		return taskid;
	}

	public void setTaskid(String taskid) {
		this.taskid = taskid;
	}

	public String getAssignedby() {
		return assignedby;
	}

	public void setAssignedby(String assignedby) {
		this.assignedby = assignedby;
	}

	public String getAssignee() {
		return assignee;
	}

	public void setAssignee(String assignee) {
		this.assignee = assignee;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	public String getUpdate() {
		return update;
	}

	public void setUpdate(String update) {
		this.update = update;
	}

	public String getCreatedate() {
		return createdate;
	}

	public void setCreatedate(String createdate) {
		this.createdate = createdate;
	}

		public task(){}

		//used by excel operation
		public task(String tid,String ab,String a,String d){
			
			this.taskid=tid; this.assignedby=ab; this.assignee=a; this.details=d;
		}
		
	public task(String a, String b,String c,String d,String e,String f,String g) {
		this.taskid=a;
		this.assignedby=b;
		this.assignee=c;
		this.status=d;
		this.details=e;
		this.update=f;
		this.createdate=g;
	}


	  @Override
	    public String toString() {
	        return String.format(
"Task Details->[TASK ID='%s',TASK ASSIGNED BY='%s',TASK ASSIGNED TO ='%s' , TASK STATUS = '%s',TASK DETAILS ='%s',TASK UPDATES ='%s',TASK CREATE DATE='%s']",
	        		taskid,assignedby,assignee,status,details,update,createdate);
	    }

}

