package com.suntrust.support.dao;

import java.beans.PropertyVetoException;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import org.springframework.web.servlet.view.JstlView;

import com.mchange.v2.c3p0.ComboPooledDataSource;

@Configuration
@ComponentScan(basePackages="com.suntrust.support")
@EnableWebMvc
public class DataBaseConfig extends WebMvcConfigurerAdapter {
	
	
	@Value("${spring.datasource.url}")
	private String dburl;
	@Value("${spring.datasource.username}")
	private String user;
	@Value("${spring.datasource.password}")
	private String pass;
	@Value("${spring.datasource.driver-class-name}")
	private String driver;
	
	 @Bean
	    public DataSource dataSource() throws SQLException, PropertyVetoException  {
		  	ComboPooledDataSource datasource = new ComboPooledDataSource();
	       //getting datasource using hibernate 
		  	//DriverManagerDataSource datasource = new DriverManagerDataSource();
		  	
		  	//getting datasource C3P0 connection Pooling 
	        datasource.setDriverClass(oracle.jdbc.driver.OracleDriver.class.getName());
	        datasource.setJdbcUrl(dburl);
	        datasource.setUser(user);
	        datasource.setPassword(pass);
	        datasource.setMinPoolSize(50);
	        datasource.setMaxPoolSize(1000);
	        return datasource;
	    }
	  
		@Bean
		public BCryptPasswordEncoder passwordEncoder() {
			BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();
			return bCryptPasswordEncoder;
		}
		
		
	  @Bean
	  public ViewResolver internalResourceViewResolver() {
	      InternalResourceViewResolver bean = new InternalResourceViewResolver();
	      bean.setViewClass(JstlView.class);
	      bean.setPrefix("/WEB-INF/jsp/");
	      bean.setSuffix(".jsp");
	      return bean;
	  }
	     

}
