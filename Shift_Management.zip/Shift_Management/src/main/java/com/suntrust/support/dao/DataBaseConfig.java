package com.suntrust.support.dao;

import java.beans.PropertyVetoException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import org.springframework.web.servlet.view.JstlView;

import com.mchange.v2.c3p0.ComboPooledDataSource;

@Configuration
@ComponentScan(basePackages="com.suntrust.support")
@EnableWebMvc
public class DataBaseConfig extends WebMvcConfigurerAdapter {
	
	
	@Value("${spring.datasource.url}")
	private String dburl;
	@Value("${spring.datasource.username}")
	private String user;
	@Value("${spring.datasource.password}")
	private String pass;
	@Value("${spring.datasource.driver-class-name}")
	private String driver;
	
	 @Bean
	    public DataSource dataSource() throws SQLException, PropertyVetoException  {
		  	ComboPooledDataSource datasource = new ComboPooledDataSource();
	       //getting datasource using hibernate 
		  	//DriverManagerDataSource datasource = new DriverManagerDataSource();
		  	
		  	//getting datasource C3P0 connection Pooling 
	        datasource.setDriverClass(oracle.jdbc.driver.OracleDriver.class.getName());
	        datasource.setJdbcUrl(dburl);
	        datasource.setUser(user);
	        datasource.setPassword(pass);
	        datasource.setMinPoolSize(10);
	        datasource.setMaxPoolSize(100);
	        
	     	        return datasource;
	    }
	  
	  
	 public enum ConnectionManager {
		    INSTANCE;

		    private DataSource ds = null;
		    private Lock connectionLock = new ReentrantLock();

		    ConnectionManager() {
		      try {
		         final Context initCtx = new InitialContext();
		         final Context envCtx = (Context) initCtx.lookup("java:comp/env");
		         ds = (DataSource) envCtx.lookup("jdbc/ConnectionManager");
		      } catch (NamingException e) {
		         e.printStackTrace();
		      }
		    }

		   public Connection getConnection() throws SQLException {
		      if(ds == null) return null;

		      Connection conn = null;
		      connectionLock.lock();
		      try {
		          conn = ds.getConnection();
		      } finally {
		          connectionLock.unlock();
		      }

		      return conn;
		   }
		}
	 
	
	 
	 
	 
	 
		@Bean
		public BCryptPasswordEncoder passwordEncoder() {
			BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();
			return bCryptPasswordEncoder;
		}
		
		
	  @Bean
	  public ViewResolver internalResourceViewResolver() {
	      InternalResourceViewResolver bean = new InternalResourceViewResolver();
	      bean.setViewClass(JstlView.class);
	      bean.setPrefix("/WEB-INF/jsp/");
	      bean.setSuffix(".jsp");
	      return bean;
	  }
	     

}
