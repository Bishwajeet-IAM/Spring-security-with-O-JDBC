package com.suntrust.support.model;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class data implements Serializable {

	
	private String dt,sh,racf,oi,ri,inc,comnt;
	
	//Getter and setter methods 
 

	
	
	public String getDt() {
		return dt;
	}

	public void setDt(String dt) {
		this.dt = dt;
	}

	public String getSh() {
		return sh;
	}

	public void setSh(String sh) {
		this.sh = sh;
	}

	public String getRacf() {
		return racf;
	}

	public void setRacf(String racf) {
		this.racf = racf;
	}

	public String getOi() {
		return oi;
	}

	public void setOi(String oi) {
		this.oi = oi;
	}

	public String getRi() {
		return ri;
	}

	public void setRi(String ri) {
		this.ri = ri;
	}

	public String getInc() {
		return inc;
	}

	public void setInc(String inc) {
		this.inc = inc;
	}

	public String getComnt() {
		return comnt;
	}

	public void setComnt(String comnt) {
		this.comnt = comnt;
	}

	public data(){}
	
	public data(String a, String b,String c,String d,String e,String f,String g) {
		this.dt=a;this.sh=b;this.racf=c;this.oi=d;this.ri=e;this.inc=f;
		this.comnt=g;
	}
	
	  @Override
	    public String toString() {
	        return String.format(
"Shift handover Details->[On Date='%s',On Shift='%s',Employee with Racf Id='%s' || Ongoing= '%s',Resolved='%s',Incident='%s',COmment='%s'",
dt,sh,racf,oi,ri,inc,comnt);
	    }

}

