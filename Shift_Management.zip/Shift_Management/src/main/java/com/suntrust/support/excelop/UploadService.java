package com.suntrust.support.excelop;


import static java.util.stream.Collectors.toMap;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.suntrust.support.dao.EmpInterface;
import com.suntrust.support.dao.ImplementInterface;
import com.suntrust.support.model.emp;
import com.suntrust.support.model.task;


@Service
public class UploadService {
	
	@Autowired  
	UploadUtil uploadUtil;
	
	@Autowired 
	EmpInterface im;

List<task> ta = new ArrayList<task>();
emp em = new emp ();
String tid,a,d,p,app,td,env;
//String [] [] str = new String [0][0];


	public List<task> upload(MultipartFile file , String ab) throws Exception {

		
		Path tempDir = Files.createTempDirectory("");

		File tempFile = tempDir.resolve(file.getOriginalFilename()).toFile();
		
		file.transferTo(tempFile);

		Workbook workbook = WorkbookFactory.create(tempFile);

		Sheet sheet = workbook.getSheetAt(0); //Which sheet of excel workbook to be read, now 0 ,means sheet1
		//Iterator rows = sheet.rowIterator();
		 
       // int minrow=sheet.getFirstRowNum();
        int maxrow=sheet.getLastRowNum();
        
        //getting total column size for each row
        Supplier<Stream<Row>> rowStreamSupplier = uploadUtil.getRowStreamSupplier(sheet);
        		Row headerRow = rowStreamSupplier.get().findFirst().get();
        		List<String> headerCells = uploadUtil.getStream(headerRow)
        				.map(Cell::getStringCellValue)
        				.map(String::valueOf)
        				.collect(Collectors.toList());
        int  colCount = headerCells.size();
        
        String [] [] str = new String [maxrow+1][colCount+1];
        
        DataFormatter formatter = new DataFormatter();
        
        try{
        for (int i = 0 ; i<= maxrow ; i++){
        	for (int j =0; j<=colCount ; j++){
        		
        		str[i][j]=formatter.formatCellValue(sheet.getRow(i).getCell(j));
        	}
        }
        }catch(Exception e ){
        	
        	ta.add(new task ("","","","Some error occured with Excel file, please make sure the cell format of excel file and Retry...!!"));
        	return ta;
        }
        
        
        for (int k=1;k<str.length;k++){
        	
        	//eta kal discuss kroe tobe set korbi excel format, and screen shot.
        	tid=str[k][2];
        	a=str[k][0];
        	app=str[k][3];
        	p=str[k][4];
        	env=str[k][1];
        	d=str[k][5];
        	
        	em = im.searchonememp(a);
			
			if( em == null ){
				
				ta.add(new task (tid,ab,a+" -Racf Id not found!","Task has not created !\n Please insert correct RacfID or create this employee") );
			}
			
			else {
				a=em.getName()+"["+em.getRacfid()+"]";
				td=im.bulktask(tid, ab, a, d, p, app,env);
				ta.add(new task (tid,ab,a,td));
			}
        	
        }

        return ta;
	}
	
	
	}
