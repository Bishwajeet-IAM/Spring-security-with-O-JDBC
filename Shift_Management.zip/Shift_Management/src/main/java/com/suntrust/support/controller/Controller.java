package com.suntrust.support.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.security.Principal;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import com.suntrust.support.dao.*;
import com.suntrust.support.model.*;

@SuppressWarnings("serial")
@XmlRootElement
@RestController
public class Controller extends HttpServlet {
	
	@Autowired
	EmpInterface EI;
	
	String msg= null;
	
	public List <data> L = new ArrayList<data>();
	public List <task> TL = new ArrayList<task>();
	public List <emp> E = new ArrayList <emp>();
	
	public task T = new task ();
	public emp e = new emp () ;
	
	String task_add_response= "No Recent data entry";
	String emp_add_response= "No Recent data entry";
	String Taskupdatesearch_response= "No Recent data entry";
	String add_response = "No Recent data entry";

	//Login page
	   @RequestMapping(value = "/login", method = RequestMethod.GET)
	    public ModelAndView loginPage(@RequestParam(value = "error",required = false) String error,
	            @RequestParam(value = "logout", required = false) String logout) {

	        ModelAndView model = new ModelAndView();
	        if (error != null) {
	            model.addObject("msg", "Invalid RacfId OR Password !!!! Kindly try again.....");
	        }

	        if (logout != null) {
	            model.addObject("msg", "You are successfully logged out from this application.....");
	        }

	        model.setViewName("login");
	        return model;
	    }
	   
	
	//Forgot Password page
	@RequestMapping(value="/fp", method = RequestMethod.GET )
	public ModelAndView  fp() {
		
		ModelAndView mod = new ModelAndView("fp");
		mod.setViewName("fp");
		return mod;
		} 
	
	
	//Welcome page
	@RequestMapping(value="/shift/welcome", method = RequestMethod.GET )
	public ModelAndView  welcome(Principal pr) {
		
		ModelAndView mod = new ModelAndView("welcome");
		mod.setViewName("welcome");
		mod.addObject("user",pr);
		return mod;
		
		} 
	
	//ALL METHODS FOR shift handover data submit....
	@RequestMapping(value="/shift/add", method = RequestMethod.GET )
	public ModelAndView  add(Principal pr) {

		ModelAndView mod = new ModelAndView("add");
		mod.setViewName("add");
		mod.addObject("user",pr);
		return mod;
	
}
	
	@RequestMapping(value="/shift/add", method = RequestMethod.POST )
	public RedirectView addemp(HttpServletRequest request,HttpServletResponse response)
			throws ServletException, IOException {
		
		String a = request.getParameter("Date_Time");
		String b = request.getParameter("Shift");
		String c = request.getParameter("Racf_Id");
		String d = request.getParameter("Ongoing_Issue");
		String e = request.getParameter("Resolved_Issue");
		String f = request.getParameter("Incident");
		String g = request.getParameter("Commentt");
		
		data emp=new data (a,b,c,d,e,f,g);
		String ex=emp.toString();
		//System.out.println("inside add-------------"+ex);
		add_response=EI.Add(emp);
		//System.out.println(add_response);
		
		return new RedirectView("/shift/addredirect");
		
	}
	
	@RequestMapping(value="/shift/addredirect", method = RequestMethod.GET )
	public ModelAndView  addredirect(Principal pr) {
					
			ModelAndView mod = new ModelAndView("addredirect");
			mod.setViewName("addredirect");
			mod.addObject("Li",add_response);
			mod.addObject("user",pr);
			return mod;
			} 	
	

	//ALL METHODS FOR shift handover report PAGE.....
	@RequestMapping(value="/shift/get", method = RequestMethod.GET )
	public ModelAndView  gett(Principal pr) {

		ModelAndView mod = new ModelAndView("get");
		mod.setViewName("get");
		mod.addObject("user",pr);
		return mod;
	}
	
	@RequestMapping(value="/shift/get", method = RequestMethod.POST )
	public RedirectView getemp(HttpServletRequest request,HttpServletResponse response)
			throws ServletException, IOException {

		//response.setContentType("text/html");
		//PrintWriter out = response.getWriter();
		
		String Dt=null,S=null,Rcf=null;
		  Dt = request.getParameter("Date_Time");
		  S = request.getParameter("Shift");
		 Rcf = request.getParameter("Racf_Id");
		
		//System.out.println("inside get-------------,Racf="+Rcf+"DateTime="+Dt+"Shift="+S);
		L=EI.get_R(Rcf,Dt,S);
		//System.out.print(L);
		
		return new RedirectView("/shift/all");
	}
	
	
	
	@RequestMapping(value="/shift/all", method = RequestMethod.GET )
	public ModelAndView  all(Principal pr) {
		
		ModelAndView mo = new ModelAndView("all");
		
		//System.out.println("inside all-------------");
		 List <data> Ll = new ArrayList<data>();
		 Ll=L;
		//System.out.print(Ll);
		mo.setViewName("all");
		mo.addObject("Lis",Ll);
		mo.addObject("user",pr);
		return mo;
		} 
	
	//Help page
	@RequestMapping(value="/shift/help", method = RequestMethod.GET )
	public ModelAndView  help(Principal pr) {
		ModelAndView mo = new ModelAndView("help");	
		mo.setViewName("help");
		mo.addObject("user",pr);
		return mo;
		
	}
	
	//ALL METHODS FOR TASK PAGE.....
	@RequestMapping(value="/shift/task", method = RequestMethod.GET )
	public ModelAndView  task(Principal pr) {
		ModelAndView mo = new ModelAndView("task");
		mo.setViewName("task");
		mo.addObject("user",pr);
		return mo;		
}
	

	@RequestMapping(value="/shift/task", method = RequestMethod.POST )
	public RedirectView updatesearchtask(HttpServletRequest request,HttpServletResponse response)
			throws ServletException, IOException {

		String id=request.getParameter("taskid");
		
		//System.out.println("inside updatesearchtask-------------,TASK-ID:="+id);
		T=EI.updatesearchtask(id);
		
		return new RedirectView("/shift/taskupdatesearch");
	}

	
	@RequestMapping(value="/shift/task/search", method = RequestMethod.POST )
	public RedirectView searchtask(HttpServletRequest request,HttpServletResponse response)
			throws ServletException, IOException {

		String tid = request.getParameter("taskid");
		String ab = request.getParameter("assignedby");
		String a = request.getParameter("assignee");
		String s = request.getParameter("status");
		String cd = request.getParameter("createdate");
		
		
		//System.out.println("inside searchtask-------------,"+tid+ab+a+s+cd);
		
		TL=EI.searchtask(tid, ab, a, s, cd);
		return new RedirectView("/shift/tasksearch");
	}

	
	@RequestMapping(value="/shift/tasksearch", method = RequestMethod.GET )
	public ModelAndView  tasksearch(Principal pr) {
		
		ModelAndView mo = new ModelAndView("tasksearch");
		mo.setViewName("tasksearch");
		mo.addObject("Lis",TL);
		mo.addObject("user",pr);
		return mo;
		}


	@RequestMapping(value="/shift/taskupdatesearch", method = RequestMethod.GET )
	public ModelAndView  taskupdatesearch(Principal pr) {
		
		ModelAndView mo = new ModelAndView("taskupdatesearch");
	//	System.out.println("inside taskupdatesearch-------------"+T);
		
		mo.setViewName("taskupdatesearch");
		mo.addObject("Lis",T);
		mo.addObject("user",pr);
		return mo;
		}
	
	@RequestMapping(value="/shift/taskupdatesearch", method = RequestMethod.POST )
	public RedirectView Taskupdatesearch(HttpServletRequest request,HttpServletResponse response)
			throws ServletException, IOException {
		
		String tid = request.getParameter("taskid");
		String s = request.getParameter("status");
		String n = request.getParameter("name");
		String u = request.getParameter("update");
		
		//System.out.println("inside Taskupdatesearch-------------"+tid+s+n+u);
		
	 Taskupdatesearch_response=EI.updatetask(tid, n, u, s);
		//System.out.println(Taskupdatesearch_response);
		
		return new RedirectView("/shift/taskupdate");
	}
	
		
	
	@RequestMapping(value="/shift/taskupdate", method = RequestMethod.GET )
	public ModelAndView  taskupdate(Principal pr) {
		
		ModelAndView mod = new ModelAndView("taskupdate");
		mod.setViewName("taskupdate");
		mod.addObject("Li",Taskupdatesearch_response);
		mod.addObject("user",pr);
		return mod;
	}

	
	//ALL METHODS FOR ADMIN PAGE.....
	
	
	@RequestMapping(value="/admin", method = RequestMethod.GET )
	public ModelAndView  admin(Principal pr) {
		ModelAndView mod = new ModelAndView("admin");
		mod.setViewName("admin");
		mod.addObject("user",pr);
		return mod;
}
	//TASK ASSIGNED  BY ADMIN
	@RequestMapping(value="/admin", method = RequestMethod.POST )
	public RedirectView admintaskadd(HttpServletRequest request,HttpServletResponse response)
			throws ServletException, IOException {
		
		String ab = request.getParameter("assignedby");
		String a = request.getParameter("assignee");
		String d = request.getParameter("details");
		
		//System.out.println("inside adminTASKadd-------------"+ab+a+d);
		
		task_add_response=EI.addtask(ab, a, d);
		//System.out.println(task_add_response);
		
		return new RedirectView("/admin/admintaskadd");
	}

	//TASK UPDATE BY ADMIN
	@RequestMapping(value="/admin/taskupdate", method = RequestMethod.POST )
	public RedirectView admintaskupdate(HttpServletRequest request,HttpServletResponse response)
			throws ServletException, IOException {
		
		String t = request.getParameter("taskid");
		String a = request.getParameter("assignee");
		String d = request.getParameter("details");
		
		//System.out.println("inside adminTASK-UPDATE-------------"+t+a+d);
		
		task_add_response=EI.taskupdatebyadmin(t, d, a);
		//System.out.println(task_add_response);
		
		return new RedirectView("/admin/admintaskadd");
	}
	
	@RequestMapping(value="/admin/admintaskadd", method = RequestMethod.GET )
	public ModelAndView  addmintaskadd(Principal pr) {
					
			ModelAndView mod = new ModelAndView("admintaskadd");
			mod.setViewName("admintaskadd");
			mod.addObject("Li",task_add_response);
			mod.addObject("user",pr);
			return mod;
			} 	
	
	
	//EMPLOYEE PROVISION BY ADMIN
	@RequestMapping(value="/admin/empadd", method = RequestMethod.POST )
	public RedirectView empadd(HttpServletRequest request,HttpServletResponse response)
			throws ServletException, IOException {
		

String id = request.getParameter("racfid");
String n = request.getParameter("name");
String e = request.getParameter("email");
String p = "Suntrust123";  //HERE A DEFAULT PASSWORD IS BEING SETTING UP ................request.getParameter("password");
String t = request.getParameter("ph");
String r = request.getParameter("role");

		
		//System.out.println("inside emp_add_-------------"+id+n+e+p+t+r);
		
		emp_add_response= EI.addemp(id, n, e, p, t, r);
		
	//	System.out.println(emp_add_response);
		
		return new RedirectView("/shift/adminempadd");
	}
	
	
	//EMPLOYEE update BY ADMIN
		@RequestMapping(value="/admin/empupdate", method = RequestMethod.POST )
		public RedirectView empupdateadmin(HttpServletRequest request,HttpServletResponse response)
				throws ServletException, IOException {
			

	String id = request.getParameter("racfid");
	String n = request.getParameter("name");
	String e = request.getParameter("email");
	String p = "Suntrust123";  //request.getParameter("password");
	String t = request.getParameter("ph");
	String r = request.getParameter("role");
	String en=request.getParameter("en");

			
			//System.out.println("inside emp_add_-------------"+id+n+e+p+t+r);
			
			emp_add_response= EI.updateemp(id, n, e, p, t, r,en);
			
			//System.out.println(emp_add_response);
			
			return new RedirectView("/shift/adminempadd");
		}
		
		
	
	@RequestMapping(value="/shift/adminempadd", method = RequestMethod.GET )
	public ModelAndView  addminempadd(Principal pr) {
					
			ModelAndView mod = new ModelAndView("adminempadd");
			mod.setViewName("adminempadd");
			mod.addObject("Li",emp_add_response);
			mod.addObject("user",pr);
			return mod;
			} 	
	
	
	@RequestMapping(value="/shift/empsearch", method = RequestMethod.GET )
	public ModelAndView  empsearch(Principal pr) {
		
		ModelAndView mo = new ModelAndView("empsearch");
		E=EI.searchemp();
		//System.out.println("inside empsearch-------------");
		 List <emp> Ll = new ArrayList<emp>();
		 Ll=E;
		//System.out.print(Ll);
		mo.setViewName("empsearch");
		mo.addObject("Lis",Ll);
		mo.addObject("user",pr);
		return mo;
		} 
	
	//Admin page and methods for normal employees
	@RequestMapping(value="/shift/adusr", method = RequestMethod.GET )
	public ModelAndView  adusr(Principal pr) {
		
		ModelAndView mod = new ModelAndView("adusr");
		mod.setViewName("adusr");
		mod.addObject("user",pr);
		return mod;
		
		} 
	
	//EMPLOYEE update BY EMPLOYEE
			@RequestMapping(value="/shift/adusr", method = RequestMethod.POST )
			public RedirectView empupdate(HttpServletRequest request,HttpServletResponse response)
					throws ServletException, IOException {
				

		String id = request.getParameter("racfid");
		String n = request.getParameter("name");
		String e = request.getParameter("email");
		String p = request.getParameter("password");
		String t = request.getParameter("ph");
				
				//System.out.println("inside emp_update by employee-------------"+id+n+e+p);
				
				emp_add_response= EI.updateempbyemp(id,n,e,p,t);
				
				//System.out.println(emp_add_response);
				
				return new RedirectView("/shift/adminempadd");
			}
			
			
	}
	
