package com.suntrust.support.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.security.Principal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import com.suntrust.support.dao.*;
import com.suntrust.support.excelop.UploadService;
import com.suntrust.support.model.*;

@SuppressWarnings("serial")
@XmlRootElement
@RestController
public class Controller extends HttpServlet {
	
	@Autowired
	EmpInterface EI;
	
	@Autowired
	UploadService us;
	
	String msg= null;
	 
	public List <data> L = new ArrayList<data>();
	public List <task> TL = new ArrayList<task>();
	public List <emp> E = new ArrayList <emp>();

	public task T = new task ();
	public emp e = new emp () ;
	
	
	String dt,shif;
	String task_add_response= "No Recent data entry";
	String emp_add_response= "No Recent data entry";
	String Taskupdatesearch_response= "No Recent data entry";
	String add_response = "No Recent data entry";
	

	public String CalcTime(String h,String m,String old)
			{
		String total = null;
		int h1,m1,h2,m2,M,H;
			
		String[] split = old.split("\\:");
		
		h1=Integer.parseInt(split[0].replace("-hours", ""));
		m1=Integer.parseInt(split[1].replace("-mins", ""));
		
		h2=Integer.parseInt(h);
		m2=Integer.parseInt(m);
		
		if( (m1+m2)>=60 ){
			M=(m1+m2)-60;
			H=h1+h2+1;
		}
		else{
			M=m1+m2;
			H=h1+h2;
		}
	
		total = Integer.toString(H)+ "-hours:"+Integer.toString(M)+"-mins";
		return total;
			}

	
	//Login page
	   @RequestMapping(value = "/login", method = RequestMethod.GET)
	    public ModelAndView loginPage(@RequestParam(value = "error",required = false) String error,
	            @RequestParam(value = "logout", required = false) String logout) {

	        ModelAndView model = new ModelAndView();
	        if (error != null) {
	            model.addObject("msg", "Invalid RacfId OR Password !!!! Kindly try again.....");
	        }

	        if (logout != null) {
	        	 Calendar cal = Calendar.getInstance();
	     	    Date tim=cal.getTime();
	     	
	            model.addObject("msg1", "You are successfully logged out from this application at->");
	            model.addObject("msg",tim);
	        }

	        model.setViewName("login");
	        return model;
	    }
	   
	
	//Forgot Password page
	@RequestMapping(value="/fp", method = RequestMethod.GET )
	public ModelAndView  fp() {
		
		ModelAndView mod = new ModelAndView("fp");
		mod.setViewName("fp");
		return mod;
		} 
	
	
	//Welcome page
	@RequestMapping(value="/shift/welcome", method = RequestMethod.GET )
	public ModelAndView  welcome(Principal pr) {
		
		e=EI.searchonememp(pr.getName());
		ModelAndView mod = new ModelAndView("welcome");
		mod.setViewName("welcome");
		mod.addObject("user",e);
		return mod;
		
		} 
	
	//ALL METHODS FOR shift handover data submit....
	@RequestMapping(value="/shift/shiftadd", method = RequestMethod.GET )
	public ModelAndView  shiftadd(Principal pr) {
		E=EI.searchemp();
		e=EI.searchonememp(pr.getName());
		ModelAndView mod = new ModelAndView("shiftadd");
		mod.setViewName("shiftadd");
		mod.addObject("user",e);
		mod.addObject("E",E);
		return mod;
	
}
	
	@RequestMapping(value="/shift/shiftadd", method = RequestMethod.POST )
	public RedirectView shadd(HttpServletRequest request,HttpServletResponse response)
			throws ServletException, IOException {
		
		dt = request.getParameter("Date_Time");
	   shif= request.getParameter("Shift");
	   
		return new RedirectView("/shift/add");
		
	}
	
	
	
	@RequestMapping(value="/shift/add", method = RequestMethod.GET )
	public ModelAndView  add(Principal pr) {
		
		e=EI.searchonememp(pr.getName());
		ModelAndView mod = new ModelAndView("add");
		mod.setViewName("add");
		
		List <task> ct = new ArrayList<task>();
		List <task> nt = new ArrayList<task>();
		List <task> it = new ArrayList<task>();
		
		String id=e.getName()+"["+e.getRacfid()+"]";
		
		ct=EI.searchend(id,dt);  //end date agar aj ka date hai to include. 
		
		nt=EI.searchtask("","",id,"ASSIGNED","","","","","");
		it=EI.searchtask("","",id,"IN PROGRESS","","","","","");		
		
		mod.addObject("user",e);
		mod.addObject("ct",ct);
		mod.addObject("nt",nt);
		mod.addObject("it",it);
		mod.addObject("dt",dt);
		mod.addObject("s",shif);
		return mod;
	
}
	
	@RequestMapping(value="/shift/add", method = RequestMethod.POST )
	public RedirectView addemp(HttpServletRequest request,HttpServletResponse response)
			throws ServletException, IOException {
		
		String a = request.getParameter("Date_Time");
		String b = request.getParameter("shift");
		String c = request.getParameter("Racf_Id");
		String d = request.getParameter("Ongoing_Issue");
		String e = request.getParameter("Resolved_Issue");
		String f = request.getParameter("Incident");
		String g = request.getParameter("Commentt");
		
		data emp=new data (a,b,c,d,e,f,g);
		String ex=emp.toString();
		//System.out.println("inside add-------------"+ex);
		add_response=EI.Add(emp);
		//System.out.println(add_response);
		
		return new RedirectView("/shift/addredirect");
		
	}
	
	@RequestMapping(value="/shift/addredirect", method = RequestMethod.GET )
	public ModelAndView  addredirect(Principal pr) {
					
		e=EI.searchonememp(pr.getName());
			ModelAndView mod = new ModelAndView("addredirect");
			mod.setViewName("addredirect");
			mod.addObject("Li",add_response);
			mod.addObject("user",e);
			return mod;
			} 	
	

	//ALL METHODS FOR shift handover report PAGE.....
	
	@RequestMapping(value="/shift/get", method = RequestMethod.POST )
	public RedirectView getemp(HttpServletRequest request,HttpServletResponse response)
			throws ServletException, IOException {

		//response.setContentType("text/html");
		//PrintWriter out = response.getWriter();
		
		String sd,ed,S,Rcf;
		  sd = request.getParameter("r1");
		  ed = request.getParameter("r2");
		  S = request.getParameter("Shift");
		 Rcf = request.getParameter("Racf_Id");
		
		//System.out.println("inside get-------------,Racf="+Rcf+"DateTime="+Dt+"Shift="+S);
		L=EI.searchshift(Rcf,S,sd,ed);
		//System.out.print(L);
		
		return new RedirectView("/shift/all");
	}
	
	
	
	@RequestMapping(value="/shift/all", method = RequestMethod.GET )
	public ModelAndView  all( Principal pr)  throws ServletException, IOException {		
		ModelAndView mo = new ModelAndView("all");
		List <data> Ll = new ArrayList<data>();
		e=EI.searchonememp(pr.getName());
		Ll=L;
		
		mo.setViewName("all");
		mo.addObject("Lis",Ll);
		mo.addObject("user",e);
		return mo;
		} 
	
	//Help page
	@RequestMapping(value="/shift/help", method = RequestMethod.GET )
	public ModelAndView  help(Principal pr) {
		ModelAndView mo = new ModelAndView("help");	
		e=EI.searchonememp(pr.getName());
		mo.setViewName("help");
		mo.addObject("user",e);
		return mo;
		
	}
	
	//ALL METHODS FOR TASK PAGE.....
	@RequestMapping(value="/shift/task", method = RequestMethod.GET )
	public ModelAndView  task(Principal pr) {
		ModelAndView mo = new ModelAndView("task");
		e=EI.searchonememp(pr.getName());
		E=EI.searchemp();
		List<app> A = new ArrayList<app>();
		A=EI.searchapp();
		
		
		List <task> nnt = new ArrayList<task>();
		List <task> it = new ArrayList<task>();
		List <task> nt = new ArrayList<task>();
		
		String id=e.getName()+"["+e.getRacfid()+"]";
		
		nnt=EI.searchtask("","",id,"ASSIGNED","","","","","");
		it=EI.searchtask("","",id,"IN PROGRESS","","","","","");
		
		nt.addAll(nnt);
		nt.addAll(it);
		
		mo.setViewName("task");
		mo.addObject("A",A);	
		mo.addObject("nt",nt);
		mo.addObject("user",e);
		mo.addObject("E",E);
		return mo;		
}
	
	//Method for 1 task modify by employee
	@RequestMapping(value="/shift/task", method = RequestMethod.POST )
	public RedirectView updatesearchtask(HttpServletRequest request,HttpServletResponse response)
			throws ServletException, IOException {

		String id=request.getParameter("taskid");

		T=EI.updatesearchtask(id);
		String status = T.getStatus();
		if(status.equals("COMPLETED")){
			
			return new RedirectView("/shift/completedtask"); 
		}
		else
		
		return new RedirectView("/shift/taskupdatesearch");
	}

	//Task search
	@RequestMapping(value="/shift/task/search", method = RequestMethod.POST )
	public RedirectView searchtask(HttpServletRequest request,HttpServletResponse response)
			throws ServletException, IOException {

		String tid = request.getParameter("taskid");
		String ab = request.getParameter("assignedby");
		String a = request.getParameter("assignee");
		String s = request.getParameter("status");
		String sd = request.getParameter("r1");
		String ed = request.getParameter("r2");
		String p = request.getParameter("priority");
		String app = request.getParameter("app");
		String env = request.getParameter("env");
		
	//	System.out.println("inside searchtask-------------,"+tid+ab+a+s+sd+ed);
		
		TL=EI.searchtask(tid, ab, a, s, sd,ed,p,app,env);
		return new RedirectView("/shift/tasksearch");
	}

	
	@RequestMapping(value="/shift/tasksearch", method = RequestMethod.GET )
	public ModelAndView  tasksearch(Principal pr) {
		e=EI.searchonememp(pr.getName());
		ModelAndView mo = new ModelAndView("tasksearch");
		mo.setViewName("tasksearch");
		mo.addObject("Lis",TL);
		mo.addObject("user",e);
		return mo;
		}


	@RequestMapping(value="/shift/completedtask", method = RequestMethod.GET )
	public ModelAndView  complete(Principal pr) {
		
		e=EI.searchonememp(pr.getName());
		ModelAndView mo = new ModelAndView("completedtask");
	//	System.out.println("inside taskupdatesearch-------------"+T);
		
		mo.setViewName("completedtask");
		mo.addObject("Lis",T);
		mo.addObject("user",e);
		return mo;
		}
	
	
	@RequestMapping(value="/shift/taskupdatesearch", method = RequestMethod.GET )
	public ModelAndView  taskupdatesearch(Principal pr) {
		
		e=EI.searchonememp(pr.getName());
		ModelAndView mo = new ModelAndView("taskupdatesearch");
	//	System.out.println("inside taskupdatesearch-------------"+T);
		
		mo.setViewName("taskupdatesearch");
		mo.addObject("Lis",T);
		mo.addObject("user",e);
		return mo;
		}
	
	//Method to update a task by employee...
	@RequestMapping(value="/shift/taskupdatesearch", method = RequestMethod.POST )
	public RedirectView Taskupdatesearch(HttpServletRequest request,HttpServletResponse response)
			throws ServletException, IOException {
		
		String tid = request.getParameter("taskid");
		String s = request.getParameter("status");
		String n = request.getParameter("name");
		String u = request.getParameter("update");
		
		String h = request.getParameter("h");
		String m = request.getParameter("m");
		
		String ntim = h+"-hours:"+m+"-mins";
		
		task tt = new task ();
		tt = EI.updatesearchtask(tid);
		
		if( tt != null ){
		String ti=CalcTime(h,m,tt.getTime());
		
		Taskupdatesearch_response=EI.updatetask(tid, n, u, s,ti,ntim);
		}
		else
			Taskupdatesearch_response=tid+" -Could not be find, please check and try again ..!!!";
	
		
		return new RedirectView("/shift/taskupdate");
	}
	
		
	
	@RequestMapping(value="/shift/taskupdate", method = RequestMethod.GET )
	public ModelAndView  taskupdate(Principal pr) {
		e=EI.searchonememp(pr.getName());
		ModelAndView mod = new ModelAndView("taskupdate");
		mod.setViewName("taskupdate");
		mod.addObject("Li",Taskupdatesearch_response);
		mod.addObject("user",e);
		return mod;
	}

	
	//ALL METHODS FOR ADMIN PAGE.....
	
	
	@RequestMapping(value="/admin", method = RequestMethod.GET )
	public ModelAndView  admin(Principal pr) {
		ModelAndView mod = new ModelAndView("admin");
		e=EI.searchonememp(pr.getName());
		E=EI.searchemp();
		List<app> A = new ArrayList<app>();
		A=EI.searchapp();
		mod.setViewName("admin");
		
		mod.addObject("A",A);
		
		mod.addObject("user",e);
		mod.addObject("E",E);
		
		return mod;
}
	
	//TASK ASSIGNED  BY ADMIN
	@RequestMapping(value="/admin", method = RequestMethod.POST )
	public RedirectView admintaskadd(HttpServletRequest request,HttpServletResponse response)
			throws ServletException, IOException {
		
		String ab = request.getParameter("assignedby");
		String a = request.getParameter("assignee");
		String d = request.getParameter("details");
		String p = request.getParameter("priority");
		String app = request.getParameter("app");
		String env = request.getParameter("env");
		
		task_add_response=EI.addtask(ab, a, d,p,app,env);
		//System.out.println(task_add_response);
		
		return new RedirectView("/admin/admintaskadd");
	}

	//TASK UPDATE BY ADMIN
	@RequestMapping(value="/admin/taskupdate", method = RequestMethod.POST )
	public RedirectView admintaskupdate(HttpServletRequest request,HttpServletResponse response)
			throws ServletException, IOException {
		
		String ab = request.getParameter("assignedby");
		String t = request.getParameter("taskid");
		String a = request.getParameter("assignee");
		String d = request.getParameter("details");
		String p = request.getParameter("priority");
		String app = request.getParameter("app");
		String env = request.getParameter("env");
		
		//System.out.println("inside adminTASK-UPDATE-------------"+t+a+d);
		
		task_add_response=EI.taskupdatebyadmin(t, d,ab,a,p,app,env);
		//System.out.println(task_add_response);
		
		return new RedirectView("/admin/admintaskadd");
	}
	
	@RequestMapping(value="/admin/admintaskadd", method = RequestMethod.GET )
	public ModelAndView  addmintaskadd(Principal pr) {
		e=EI.searchonememp(pr.getName());
			ModelAndView mod = new ModelAndView("admintaskadd");
			mod.setViewName("admintaskadd");
			mod.addObject("Li",task_add_response);
			mod.addObject("user",e);
			return mod;
			} 	
	
	
	//Bulk task assign using excel	
	@RequestMapping(value="/admin/bulktaskadd", method = RequestMethod.POST, headers="Content-Type=multipart/form-data")
	public @ResponseBody RedirectView bulktaskadd(HttpServletRequest request,HttpServletResponse response, @RequestParam(value = "file") MultipartFile file)
			throws Exception {

		String id=e.getName()+"["+e.getRacfid()+"]";
		
		TL=us.upload(file,id);
	    
		return new RedirectView("/admin/bulktask");
		
	}

	@RequestMapping(value="/admin/bulktask", method = RequestMethod.GET )
	public ModelAndView  bulktask(Principal pr) {
		e=EI.searchonememp(pr.getName());
		ModelAndView mod = new ModelAndView("bulktask");
		mod.setViewName("bulktask");
		mod.addObject("Lis",TL);
		mod.addObject("user",e);
		return mod;
	}

	//Bulk task update for inhouse task by ADMIN
	@RequestMapping(value="/admin/btupdate", method = RequestMethod.GET )
	public ModelAndView  btupdate(Principal pr) {
		
		e=EI.searchonememp(pr.getName());
		ModelAndView mo = new ModelAndView("btupdate");
	//	System.out.println("inside taskupdatesearch-------------"+T);
		
		List <task> nt = new ArrayList<task>();
		List <task> it = new ArrayList<task>();
		List <task> tt = new ArrayList<task>();
		
		nt=EI.searchtask("","","","ASSIGNED","","","","","");
		it=EI.searchtask("","","","IN PROGRESS","","","","","");
		
		tt.addAll(nt);
		tt.addAll(it);
		
		mo.setViewName("btupdate");
		mo.addObject("Lis",tt);
		mo.addObject("user",e);
		return mo;
		}
	
	//EMPLOYEE PROVISION BY ADMIN
	@RequestMapping(value="/admin/empadd", method = RequestMethod.POST )
	public RedirectView empadd(HttpServletRequest request,HttpServletResponse response)
			throws ServletException, IOException {
		

String id = request.getParameter("racfid");
String n = request.getParameter("name");
String ln = request.getParameter("lname");
String e = request.getParameter("email");
String p = "Suntrust123";  //HERE A DEFAULT PASSWORD IS BEING SETTING UP ................request.getParameter("password");
String t = request.getParameter("ph");
String r = request.getParameter("role");

		
		//System.out.println("inside emp_add_-------------"+id+n+e+p+t+r);
		
		emp_add_response= EI.addemp(id, n,ln, e, p, t, r);
		
	//	System.out.println(emp_add_response);
		
		return new RedirectView("/shift/adminempadd");
	}
	
	
	//EMPLOYEE update BY ADMIN
		@RequestMapping(value="/admin/empupdate", method = RequestMethod.POST )
		public RedirectView empupdateadmin(HttpServletRequest request,HttpServletResponse response)
				throws ServletException, IOException {
			

	String id = request.getParameter("racfid");
	String n = request.getParameter("name");
	String ln = request.getParameter("lname");
	String e = request.getParameter("email");
	String p = "Suntrust123";  //request.getParameter("password");
	String t = request.getParameter("ph");
	String r = request.getParameter("role");
	String en=request.getParameter("en");

	
		//	System.out.println("inside emp_UPATE BY ADMIN-------------"+id+n+ln+e+p+t+r+en);
			
			emp_add_response= EI.updateemp(id, n, ln,e, p, t, r,en);
			
			//System.out.println(emp_add_response);
			
			return new RedirectView("/shift/adminempadd");
		}
		
		
	
	@RequestMapping(value="/shift/adminempadd", method = RequestMethod.GET )
	public ModelAndView  addminempadd(Principal pr) {
		e=EI.searchonememp(pr.getName());
			ModelAndView mod = new ModelAndView("adminempadd");
			mod.setViewName("adminempadd");
			mod.addObject("Li",emp_add_response);
			mod.addObject("user",e);
			return mod;
			} 	
	
	
	@RequestMapping(value="/shift/empsearch", method = RequestMethod.GET )
	public ModelAndView  empsearch(Principal pr) {
		e=EI.searchonememp(pr.getName());
		ModelAndView mo = new ModelAndView("empsearch");
		E=EI.searchemp();
		
		 List <emp> Ll = new ArrayList<emp>();
		 Ll=E;
		
		mo.setViewName("empsearch");
		mo.addObject("Lis",Ll);
		mo.addObject("user",e);
		return mo;
		} 
	
	//Admin page and methods for normal employees
	@RequestMapping(value="/shift/adusr", method = RequestMethod.GET )
	public ModelAndView  adusr(Principal pr) {
		e=EI.searchonememp(pr.getName());
		ModelAndView mod = new ModelAndView("adusr");
		mod.setViewName("adusr");
		mod.addObject("user",e);
		return mod;
		
		} 
	
	//EMPLOYEE update BY EMPLOYEE
			@RequestMapping(value="/shift/adusr", method = RequestMethod.POST )
			public RedirectView empupdate(HttpServletRequest request,HttpServletResponse response)
					throws ServletException, IOException {
				

		String id = request.getParameter("racfid");
		String n = request.getParameter("name");
		String ln = request.getParameter("lname");
		String e = request.getParameter("email");
		String p = request.getParameter("password");
		String t = request.getParameter("ph");
				
				//System.out.println("inside emp_update by employee-------------"+id+n+e+p);
				
				emp_add_response= EI.updateempbyemp(id,n,ln,e,p,t);
				
				//System.out.println(emp_add_response);
				
				return new RedirectView("/shift/adminempadd");
			}
			
			
	}
	
