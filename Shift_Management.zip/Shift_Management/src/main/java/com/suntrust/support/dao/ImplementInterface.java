package com.suntrust.support.dao;

import java.beans.PropertyVetoException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.sql.DataSource;
import javax.swing.tree.RowMapper;
import javax.swing.tree.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.*;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.suntrust.support.model.*;



@Service

public class ImplementInterface implements EmpInterface {

		
	@Autowired
		DataBaseConfig db;
	
	private JdbcTemplate JT ;
	
	@Autowired
	public void setJT() throws SQLException, PropertyVetoException{
	JT= new JdbcTemplate(db.dataSource());}
	
//Method For shift handover task add
		@Override
		public String Add(data m) {
			
			try {
				 
		        String i = "INSERT INTO SHIFT (DATE_TIME,SHIFT,RACF_ID,ONGOING_ISSUE,RESOLVED_ISSUE,INCIDENT,COMMENTT)  VALUES (?, ?, ?, ?, ?, ?, ?)";
		        JT.update(i,m.getDt(),m.getSh(),m.getRacf(),m.getOi(),m.getRi(),m.getInc(),m.getComnt());
		        return "Your data has been ADDED to databse for RACF_ID:->="+m.getRacf()+",Dated on : "+m.getDt()+" ,of Shift "+m.getSh();
		        
			} 
			catch (Exception e){
				try{
					String i1="UPDATE SHIFT SET ONGOING_ISSUE =?,RESOLVED_ISSUE =?,INCIDENT =?,COMMENTT =? WHERE DATE_TIME =? AND SHIFT =? AND RACF_ID =?";

					JT.update(i1,m.getOi(),m.getRi(),m.getInc(),m.getComnt(),m.getDt(),m.getSh(),m.getRacf());
			        return "Your data has been UPDATED to databse for RACF_ID:->="+m.getRacf()+",Dated on : "+m.getDt()+" ,of Shift "+m.getSh();
				}catch (Exception e1){
					return "Please validate the entry and try again !!!!, \n Error occured -> "+e1;
				}
			    }
		}

		
		//Method For get handover data
		@Override
		public List<data> searchshift (String a,String b,String sd,String ed) {
			
			List <data> L = new ArrayList<data>();

			String sql="SELECT * FROM SHIFT WHERE ";
			
			
			String s1="RACF_ID='"+a+"'";
			String s3="SHIFT = '"+b+"'";
			String s2="DATE_TIME BETWEEN '"+sd+"' AND '"+ed+"'";
			
			int and=0;
			
			if(!a.equals("") && and == 0 )
				{sql=sql +s1;and++;}
			
			 if (!sd.equals("") && !ed.equals("") && and != 0)
				{sql=sql+" AND "+s2;and++;}
			 else if (!sd.equals("") && !ed.equals("") && and == 0)
			 {sql=sql+s2;and++;}
			 
			 if (!b.equals("") && and != 0)
				sql=sql+" AND "+s3;
			 else if (!b.equals("") && and == 0)
			 sql=sql+s3;	
			 
			// System.out.println("Inside interface method get_r.......SQL="+sql);
			
			List<Map<String, Object>> rows1 = JT.queryForList(sql);
			for (Map row : rows1) {
		
		               data emp = new data();
		              
		               emp.setRacf((String)(row.get("RACF_ID")));
		               emp.setDt((String)(row.get("DATE_TIME")));
		               emp.setSh((String)(row.get("SHIFT")));
		               emp.setOi((String)(row.get("ONGOING_ISSUE")));
		               emp.setRi((String)(row.get("RESOLVED_ISSUE")));
		               emp.setInc((String)(row.get("INCIDENT")));
		               emp.setComnt((String)(row.get("COMMENTT")));
		               
		               L.add(emp);
		            }
		 
		            return L;
		        }


		//Method For get a single task by taskid
		@Override
		public task updatesearchtask (String s){
	String sql = "SELECT * FROM SHIFT_TASK WHERE TASKID = '" + s+"'";
   return  JT.query(sql, new ResultSetExtractor<task>() {
 
        @Override
        public task extractData(ResultSet row) throws SQLException,DataAccessException {
            if (row.next()) {
            	task T = new task ();
				
				T.setTaskid(row.getString("TASKID"));
				T.setAssignedby(row.getString("ASSIGNEDBY"));
				T.setAssignee(row.getString("ASSIGNEE"));
				T.setStatus(row.getString("STATUS"));
				T.setDetails(row.getString("DETAILS"));
				T.setUpdate(row.getString("UPDTE"));
				T.setCreatedate(row.getString("CREATEDATE"));
				T.setPriority(row.getString("PRIORITY"));
				T.setApp(row.getString("APPNAME"));
				T.setEnddate(row.getString("ENDDATE"));
				T.setIntassignee(row.getString("INTASSIGNEE"));
				T.setTime(row.getString("TIME"));
				T.setEnv(row.getString("ENV"));
				
                return T;
            }
            
            
            return null;
        }
 
    });
  
}

		//Method For updating a task by employee		
		@Override
		public String updatetask(String t,String n,String u, String s,String time,String ntim) {
			 
			 Calendar cal = Calendar.getInstance();
			    Date date=cal.getTime();
			   // System.out.println("updatetask method er vitore cal="+cal+"r AGER UPDATE="+u0);
				DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
				Date f = new Date();	
				String dat=dateFormat.format(f);
				
			task ta= new task ();
			ta=updatesearchtask(t);
			
			String u0=ta.getUpdate();
			String u1 = u0+"\n\n*********The details updated by [" +n + "], on -["+date+"], is:\n[ " +u+"]\n"+"*******post update ,the TASK_STATUS is -["+s+"]*****";
			//System.out.println("new update"+u1);
			
			String intass= ta.getIntassignee() + "\n"+n+"["+ntim+"]";
			
			
			try {
			  String sql = "UPDATE SHIFT_TASK SET INTASSIGNEE=? ,TIME=? ,STATUS=?, UPDTE=?, ENDDATE=? WHERE TASKID=?";
		        JT.update(sql,intass,time,s,u1,dat,t);
		        return "The Task with TASKID="+t+" , is been updated with given details..";
			}
			catch (Exception e) {
				return "Try again with correct details, error on your action is : -"+e;
			}
			
		}

		//Method For get all tasks
		@Override
		public List<task> searchtask(String id, String ab, String a, String s, String sd,String ed,String p,String app,String env) {
			 
			int and=0;
			String sql="SELECT * FROM SHIFT_TASK WHERE ";
			
			String s1="TASKID='"+id+"'";
			String s2="ASSIGNEDBY = '"+ab+"'";
			String s3="ASSIGNEE = '"+a+"'";
			String s4="STATUS = '"+s+"'";
			String s5="CREATEDATE BETWEEN '"+sd+"' AND '"+ed+"'";
			String s6="PRIORITY='"+p+"'";
			String s7="APPNAME='"+app+"'";
			String s8="ENV='"+env+"'";
			
			if(!id.equals("") && and == 0 )
			{sql=sql +s1;and++;}
		
		 if (!ab.equals("") && and != 0)
			{sql=sql+" AND "+s2;and++;}
		 else if (!ab.equals("") && and == 0)
		 {sql=sql+s2;and++;}
		
		 if (!a.equals("") && and != 0)
			{sql=sql+" AND "+s3;and++;}
		 else if (!a.equals("") && and == 0)
		 {sql=sql+s3;and++;}
		 
		 if (!s.equals("") && and != 0)
			{sql=sql+" AND "+s4;and++;}
		 else if (!s.equals("") && and == 0)
		 {sql=sql+s4;and++;}
		 
		 if (!p.equals("") && and != 0)
			{sql=sql+" AND "+s6;and++;}
		 else if (!p.equals("") && and == 0)
		 {sql=sql+s6;and++;}
		 
		 if (!app.equals("") && and != 0)
			{sql=sql+" AND "+s7;and++;}
		 else if (!app.equals("") && and == 0)
		 {sql=sql+s7;and++;}

		 if (!env.equals("") && and != 0)
			{sql=sql+" AND "+s8;and++;}
		 else if (!env.equals("") && and == 0)
		 {sql=sql+s8;and++;}
		 
		 if (!sd.equals("") && !ed.equals("") && and != 0)
			sql=sql+" AND "+s5;
		 else if (!sd.equals("") && !ed.equals("") && and == 0)
		 sql=sql+s5;
		 
		// System.out.println("Inside interface method searchtask.......SQL="+sql);
		 
		 List <task> L = new ArrayList<task>();
		 
			List<Map<String, Object>> rows1 = JT.queryForList(sql);
			for (Map row : rows1) {
		
		               task T = new task();
		              
		               T.setTaskid((String)(row.get("TASKID")));
						T.setAssignedby((String)(row.get("ASSIGNEDBY")));
						T.setAssignee((String)(row.get("ASSIGNEE")));
						T.setStatus((String)(row.get("STATUS")));
						T.setDetails((String)(row.get("DETAILS")));
						T.setUpdate((String)(row.get("UPDTE")));
						T.setCreatedate((String)(row.get("CREATEDATE")));
						T.setPriority((String)(row.get("PRIORITY")));
						T.setApp((String)(row.get("APPNAME")));
						T.setEnddate((String)(row.get("ENDDATE")));
						T.setTime((String)(row.get("TIME")));
						T.setEnv((String)(row.get("ENV")));
						T.setIntassignee((String)(row.get("INTASSIGNEE")));
		               L.add(T);
		            }
		 
				return L;
		}
		 
		
		//Method For assign task by admin
		@Override
		public String addtask(String ab,String a,String d, String p,String app,String env) {
			// 
			Calendar cal = Calendar.getInstance();
		    Date da=cal.getTime();
		    
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			Date f = new Date();	
			String dat=dateFormat.format(f);
			
			Random rand = new Random();
			int in = rand.nextInt(1000000) ;
			
			String tid="TASK"+in;
			String s="ASSIGNED";
			String u="*********The task has been created by-["+ab+"],and assigned to ["+a+"] ,at ["+da+"]**********";
			String cd=dat;

			try {
				 // insert
		        String i = "INSERT INTO SHIFT_TASK (INTASSIGNEE,TASKID,ASSIGNEDBY,ASSIGNEE,STATUS,DETAILS,UPDTE,CREATEDATE,ENDDATE,PRIORITY,APPNAME,TIME,ENV)  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		        JT.update(i,"-",tid,ab,a,s,d,u,cd,cd,p,app,"0-hours:0-mins",env);
		        return "TASK has been created with given details as ,TASKID:->="+tid+" Assigned to -"+a+" ,With Status as "+s;
		        
			} 
			catch (Exception e){
			       
			        return "Please validate the details inserted and try again |-Java Exception :- "+e;
			        
			    }
			
			
		}


		//Method For task update by admin
		@Override
	public String taskupdatebyadmin(String t, String d, String ab,String a,String p,String app,String env) {
		
			String s="ASSIGNED";
			Calendar cal = Calendar.getInstance();
		    Date date=cal.getTime();
		    
			task tb= new task ();
			tb=updatesearchtask(t);
			
			String n= ab;
			String u1=tb.getUpdate();
			String u2=u1+"\n\n*********The Task details updated by [" +n + "], on -["+date+"],look for TASK_DETAILS for changes ****post update ,the TASK_STATUS became [ASSIGNED]*****";
	
			String d1,d2;
			if(d.equals("")){
				d2=tb.getDetails();
			}
			else{
			 d1=tb.getDetails();
			 d2=d1+"\n\n****UPDATED TASK DETAILS***\n"+d;}
			
			if(env.equals("")){env = tb.getEnv();}
			if(p.equals("")){p = tb.getPriority();}
			if(app.equals("")){app = tb.getApp();}
			if(a.equals("")){a = tb.getAssignee();}
			
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			Date f = new Date();	
			String dat=dateFormat.format(f);
			
			try{
			   String u = "UPDATE SHIFT_TASK SET ENV=? ,ASSIGNEDBY=? ,ASSIGNEE=? ,DETAILS=? ,STATUS=? ,UPDTE=? ,PRIORITY=? ,APPNAME=? ,ENDDATE=? WHERE TASKID=?";
	        JT.update(u,env,n,a,d2,s,u2,p,app,dat,t);
	       return t+" has been updated and the status is set back to 'ASSIGNED' for resources with RACF_ID :--"+a;
		}
			catch(Exception e){
				
				return "Task updation failed with given errors :-"+e;
			}
	}

		
		//Method For employee add/provision
		@Override
		public String addemp(String id, String n, String ln,String e, String p, String t, String r) {
	
			String pass = db.passwordEncoder().encode(p);
			
			String en="TRUE";
			try {
		        String i = "INSERT INTO SHIFT_EMP (RACF_ID,NAME,LNAME,EMAIL,PASSWORD,PH,STATUS,ROLE)  VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
		        JT.update(i,id,n,ln,e,pass,t,en,r);
		        return "Employee profile has been created with RACF_ID:->="+id+",Name "+n+"Email "+e+"who is assighned to ROLE: "+r;
		        
			} 
			catch (Exception e1){
			       
			        return "Please validate the details inserted and try again -Java Exception :- "+e1;
			        
			    }
		
		}

		//Method For update employee by admin
		@Override
		public String updateemp(String id,String n,String ln,String e,String p,String ph,String r,String en) {
			 
			emp oldemp = new emp();
			oldemp = searchonememp(id);
				
			if(n.equals(""))
				n=oldemp.getName();
			if(e.equals(""))
				e=oldemp.getEmail();
			if(ph.equals(""))
				ph=oldemp.getPh();
			if(r.equals(""))
				r=oldemp.getRole();
			if(en.equals(""))
					en=oldemp.getEn();
			if(ln.equals(""))
				ln=oldemp.getLname();
			
			String pass = db.passwordEncoder().encode(p);
			
			   String u = "UPDATE SHIFT_EMP SET LNAME=? ,NAME=? ,EMAIL=? ,PASSWORD=?, PH=?, ROLE=?, STATUS=? WHERE RACF_ID=?";
			   
			   try{
		        JT.update(u,ln,n,e,pass,ph,r,en,id);
		     
		        return "Employee database has been updated for RACF_ID:-"+id+"Employee role is: -"+r;
			   }
			   catch( Exception e1){
				   return "Update task failed with given errors-."+e1;
			   }
			   
		}
			   
		
		//Method For get all employees
		@Override
		public List<emp> searchemp() {
			// 
			
			List <emp> L = new ArrayList<emp>();
			String sql_1 = "SELECT * FROM SHIFT_EMP";
			List<Map<String, Object>> rows1 = JT.queryForList(sql_1);
			for (Map row : rows1) {
				emp e=new emp();
				

				e.setRacfid((String)(row.get("RACF_ID")));
				e.setName((String)(row.get("NAME")));
				e.setEmail((String)(row.get("EMAIL")));
				
				e.setPh((String)(row.get("PH")));
				e.setRole((String)(row.get("ROLE")));
				e.setLname((String)(row.get("LNAME")));
				L.add(e);
				}
			return L;
			
		
		}


		//Method For update employee by an employee
		@Override
		public String updateempbyemp(String id, String n, String ln,String e, String p, String ph) {

//			System.out.println(p+"INSIDE UPDATE EMP BY EMP "+pa);
			
			emp oldemp = new emp();
			oldemp = searchonememp(id);
				
			if(n.equals(""))
				n=oldemp.getName();
			if(e.equals(""))
				e=oldemp.getEmail();
			if(ph.equals(""))
				ph=oldemp.getPh();
			if(ln.equals(""))
				ln=oldemp.getLname();
			
			String pa = db.passwordEncoder().encode(p);
			
			   String u = "UPDATE SHIFT_EMP SET LNAME=? ,NAME=? ,EMAIL=? ,PASSWORD=? ,PH=? WHERE RACF_ID=?";
			  
			   try{
		        JT.update(u,ln,n,e,pa,ph,id);
		        
		        return "Employee database has been updated for RACF_ID:-"+id;
			   }
			   catch( Exception e1){
				   return "Update task failed with given errors-."+e1;
			   }
			   
		}
		
		//Method to get a single employee data
		@Override
		public emp searchonememp(String racfid) {

			String sql = "SELECT * FROM SHIFT_EMP WHERE RACF_ID = '" + racfid+"'";
			   return  JT.query(sql, new ResultSetExtractor<emp>() {
			 
			        @Override
			        public emp extractData(ResultSet row) throws SQLException,DataAccessException {
			            if (row.next()) {
			            	emp T = new emp ();
							
							T.setRacfid(row.getString("RACF_ID"));
							T.setName(row.getString("NAME"));
							T.setLname(row.getString("LNAME"));
							T.setEmail(row.getString("EMAIL"));
							T.setPassword(row.getString("PASSWORD"));
							T.setPh(row.getString("PH"));
							T.setEn(row.getString("STATUS"));
							T.setRole(row.getString("ROLE"));
							
			                return T;
			
			            }
			            return null;
			        }
			 
			    });
			}

		@Override
		public List<app> searchapp() {
			// 

			List <app> L = new ArrayList<app>();
			String sql_1 = "SELECT * FROM SHIFT_APP";
			List<Map<String, Object>> rows1 = JT.queryForList(sql_1);
			for (Map row : rows1) {
				app e=new app();
				
				e.setAppname((String)(row.get("APP_NAME")));
				
				L.add(e);
				}
			return L;
		}

		@Override
		public List<task> searchend(String assignee,String dat) {
			
			
			
			String sql="SELECT * FROM SHIFT_TASK WHERE STATUS = 'COMPLETED' AND ASSIGNEE = '"+assignee+"' AND ENDDATE = '"+dat+"'";
			 
			//System.out.println("inside searchend-> "+sql);
			List <task> L = new ArrayList<task>();
			 
				List<Map<String, Object>> rows1 = JT.queryForList(sql);
				for (Map row : rows1) {
			
			               task T = new task();
			              
			               T.setTaskid((String)(row.get("TASKID")));
							T.setAssignedby((String)(row.get("ASSIGNEDBY")));
							T.setAssignee((String)(row.get("ASSIGNEE")));
							T.setStatus((String)(row.get("STATUS")));
							T.setDetails((String)(row.get("DETAILS")));
							T.setUpdate((String)(row.get("UPDTE")));
							T.setCreatedate((String)(row.get("CREATEDATE")));
							T.setPriority((String)(row.get("PRIORITY")));
							T.setApp((String)(row.get("APPNAME")));
							T.setEnddate((String)(row.get("ENDDATE")));
			               L.add(T);
			            }
			 
					return L;
			}

		
		//Method to create and assign task in bluk from excel file 
		@Override
		public String bulktask(String tid, String ab, String a, String d, String pri, String app,String env) {
			// 
			Calendar cal = Calendar.getInstance();
		    Date da=cal.getTime();
		    
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			Date f = new Date();	
			String dat=dateFormat.format(f);
			String cd=dat;
			String s="ASSIGNED";
			String u="*********The task has been created by-["+ab+"],and assigned to ["+a+"] ,at ["+da+"]**********";
			
			try {
				 // insert
		        String i = "INSERT INTO SHIFT_TASK (INTASSIGNEE,TASKID,ASSIGNEDBY,ASSIGNEE,STATUS,DETAILS,UPDTE,CREATEDATE,ENDDATE,PRIORITY,APPNAME,TIME,ENV)  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		        JT.update(i,"-",tid,ab,a,s,d,u,cd,cd,pri,app,"0-hours:0-mins",env);
		        return "TASK has been created successfully";
		        
			} 
			catch (Exception e){
				 
				   try{
					   
					   task old = new task ();
					   old=updatesearchtask(tid);
					   String u1=old.getUpdate();
						
					   String up=u1+"\n\n*********The task has been updated by-["+ab+"],and assigned to ["+a+"] ,at ["+da+"]**********";
					   String i2 = "UPDATE SHIFT_TASK SET ENV=? ,ASSIGNEDBY=? ,ASSIGNEE=? ,DETAILS=? ,UPDTE=? ,ENDDATE=? ,PRIORITY=? ,APPNAME=? WHERE TASKID=?";
						  
			        JT.update(i2,env,ab,a,d,up,cd,pri,app,tid);
			        
			        return "TASK has been updated with new details";
				   }
				
			       catch(Exception e1){
			        return "Error Occured | Task has not created , Please try with another Ticket-ID";
			       }
			        
			    }
			
			

		}
		
		
}
		

	