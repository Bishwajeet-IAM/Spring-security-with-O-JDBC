package com.suntrust.support.dao;

import java.beans.PropertyVetoException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.sql.DataSource;
import javax.swing.tree.RowMapper;
import javax.swing.tree.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.*;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.suntrust.support.model.*;



@Service

public class ImplementInterface implements EmpInterface {

		
	@Autowired
		DataBaseConfig db;
	
	private JdbcTemplate JT ;
	
	@Autowired
	public void setJT() throws SQLException, PropertyVetoException{
	JT= new JdbcTemplate(db.dataSource());}
	
//Method For shift handover task add
		@Override
		public String Add(data m) {
			
			try {
				 
		        String i = "INSERT INTO SHIFT (DATE_TIME,SHIFT,RACF_ID,ONGOING_ISSUE,RESOLVED_ISSUE,INCIDENT,COMMENTT)  VALUES (?, ?, ?, ?, ?, ?, ?)";
		        JT.update(i,m.getDt(),m.getSh(),m.getRacf(),m.getOi(),m.getRi(),m.getInc(),m.getComnt());
		        return "Your data has been updated to databse for RACF_ID:->="+m.getRacf()+",Dated on : "+m.getDt()+" ,of Shift "+m.getSh();
		        
			} 
			catch (Exception e){
			       
			        return "Please validate the details inserted and try again |-Java Exception :- "+e;
			        
			    }
		}

		
		//Method For get handover data
		@Override
		public List<data> get_R (String a,String b,String c) {
			
			List <data> L = new ArrayList<data>();

			String sql="SELECT * FROM SHIFT WHERE ";
			
			
			String s1="RACF_ID='"+a+"'";
			String s2="DATE_TIME = '"+b+"'";
			String s3="SHIFT = '"+c+"'";
		
			int and=0;
			
			if(!a.equals("") && and == 0 )
				{sql=sql +s1;and++;}
			
			 if (!b.equals("") && and != 0)
				{sql=sql+" AND "+s2;and++;}
			 else if (!b.equals("") && and == 0)
			 {sql=sql+s2;and++;}
			 
			 if (!c.equals("") && and != 0)
				sql=sql+" AND "+s3;
			 else if (!c.equals("") && and == 0)
			 sql=sql+s3;	
			 
			// System.out.println("Inside interface method get_r.......SQL="+sql);
			
			List<Map<String, Object>> rows1 = JT.queryForList(sql);
			for (Map row : rows1) {
		
		               data emp = new data();
		              
		               emp.setRacf((String)(row.get("RACF_ID")));
		               emp.setDt((String)(row.get("DATE_TIME")));
		               emp.setSh((String)(row.get("SHIFT")));
		               emp.setOi((String)(row.get("ONGOING_ISSUE")));
		               emp.setRi((String)(row.get("RESOLVED_ISSUE")));
		               emp.setInc((String)(row.get("INCIDENT")));
		               emp.setComnt((String)(row.get("COMMENTT")));
		               
		               L.add(emp);
		            }
		 
		            return L;
		        }


		//Method For get a single task by taskid
		@Override
		public task updatesearchtask (String s){
	String sql = "SELECT * FROM SHIFT_TASK WHERE TASKID = '" + s+"'";
   return  JT.query(sql, new ResultSetExtractor<task>() {
 
        @Override
        public task extractData(ResultSet row) throws SQLException,DataAccessException {
            if (row.next()) {
            	task T = new task ();
				
				T.setTaskid(row.getString("TASKID"));
				T.setAssignedby(row.getString("ASSIGNEDBY"));
				T.setAssignee(row.getString("ASSIGNEE"));
				T.setStatus(row.getString("STATUS"));
				T.setDetails(row.getString("DETAILS"));
				T.setUpdate(row.getString("UPDTE"));
				T.setCreatedate(row.getString("CREATEDATE"));
				
                return T;
            }
            
            
            return null;
        }
 
    });
  
}

		//Method For updating a task by employee		
		@Override
		public String updatetask(String t,String n,String u, String s) {
			 
			task ta= new task ();
			ta=updatesearchtask(t);
			String u0=ta.getUpdate();
			  Calendar cal = Calendar.getInstance();
			    Date date=cal.getTime();
			   // System.out.println("updatetask method er vitore cal="+cal+"r AGER UPDATE="+u0);
			    
			String u1 = u0+"\n\n*********The details updated by [" +n + "], on -["+date+"], is:\n[ " +u+"]\n"+"*******post update ,the TASK_STATUS is -["+s+"]*****";
			//System.out.println("notun update"+u1);
			
			try {
			  String sql = "UPDATE SHIFT_TASK SET STATUS=?, UPDTE=? WHERE TASKID=?";
		        JT.update(sql,s,u1,t);
		        return "The Task with TASKID="+t+" , is been updated with given details..";
			}
			catch (Exception e) {
				return "Try again with correct details, error on your action is : -"+e;
			}
			
		}

		//Method For get all tasks
		@Override
		public List<task> searchtask(String id, String ab, String a, String s, String d) {
			 
			int and=0;
			String sql="SELECT * FROM SHIFT_TASK WHERE ";
			
			String s1="TASKID='"+id+"'";
			String s2="ASSIGNEDBY = '"+ab+"'";
			String s3="ASSIGNEE = '"+a+"'";
			String s4="STATUS = '"+s+"'";
			String s5="CREATEDATE = '"+d+"'";
			
			if(!id.equals("") && and == 0 )
			{sql=sql +s1;and++;}
		
		 if (!ab.equals("") && and != 0)
			{sql=sql+" AND "+s2;and++;}
		 else if (!ab.equals("") && and == 0)
		 {sql=sql+s2;and++;}
		
		 if (!a.equals("") && and != 0)
			{sql=sql+" AND "+s3;and++;}
		 else if (!a.equals("") && and == 0)
		 {sql=sql+s3;and++;}
		 
		 if (!s.equals("") && and != 0)
			{sql=sql+" AND "+s4;and++;}
		 else if (!s.equals("") && and == 0)
		 {sql=sql+s4;and++;}
		 
		 if (!d.equals("") && and != 0)
			sql=sql+" AND "+s5;
		 else if (!d.equals("") && and == 0)
		 sql=sql+s5;
		 
		// System.out.println("Inside interface method searchtask.......SQL="+sql);
		 
		 List <task> L = new ArrayList<task>();
		 
			List<Map<String, Object>> rows1 = JT.queryForList(sql);
			for (Map row : rows1) {
		
		               task T = new task();
		              
		               T.setTaskid((String)(row.get("TASKID")));
						T.setAssignedby((String)(row.get("ASSIGNEDBY")));
						T.setAssignee((String)(row.get("ASSIGNEE")));
						T.setStatus((String)(row.get("STATUS")));
						T.setDetails((String)(row.get("DETAILS")));
						T.setUpdate((String)(row.get("UPDTE")));
						T.setCreatedate((String)(row.get("CREATEDATE")));
		               
		               L.add(T);
		            }
		 
				return L;
		}
		 
		
		//Method For assign task by admin
		@Override
		public String addtask(String ab,String a,String d) {
			// 
			Calendar cal = Calendar.getInstance();
		    Date da=cal.getTime();
		    
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			Date f = new Date();	
			String dat=dateFormat.format(f);
			
			Random rand = new Random();
			int in = rand.nextInt(1000000) ;
			
			String tid="TASK"+in;
			String s="ASSIGNED";
			String u="*********The task has been created by-["+ab+"],and assigned to ["+a+"] ,at ["+da+"]**********";
			String cd=dat;

			try {
				 // insert
		        String i = "INSERT INTO SHIFT_TASK (TASKID,ASSIGNEDBY,ASSIGNEE,STATUS,DETAILS,UPDTE,CREATEDATE)  VALUES (?, ?, ?, ?, ?, ?, ?)";
		        JT.update(i,tid,ab,a,s,d,u,cd);
		        return "TASK has been created to databse with given details as ,TASKID:->="+tid+" Assigned to -"+a+" ,With Status as "+s;
		        
			} 
			catch (Exception e){
			       
			        return "Please validate the details inserted and try again |-Java Exception :- "+e;
			        
			    }
			
			
		}


		//Method For task update by admin
		@Override
	public String taskupdatebyadmin(String t, String d, String a) {
		
			String s="ASSIGNED";
			Calendar cal = Calendar.getInstance();
		    Date date=cal.getTime();
		    
			task tb= new task ();
			tb=updatesearchtask(t);
			String n= tb.getAssignedby();
			String u1=tb.getUpdate();
			String u2=u1+"\n\n*********The Task details updated by [" +n + "], on -["+date+"],look for TASK_DETAILS for changes ****post update ,the TASK_STATUS became [ASSIGNED]*****";
	
			String d1=tb.getDetails();
			String d2=d1+"\n****UPDATED TASK DETAILS***\n"+d;
			try{
			   String u = "UPDATE SHIFT_TASK SET ASSIGNEE=? ,DETAILS=? ,STATUS=? ,UPDTE=? WHERE TASKID=?";
	        JT.update(u,a,d2,s,u2,t);
	       return t+" has been updated and the status is set back to 'ASSIGNED' for resources with RACF_ID :--"+a;
		}
			catch(Exception e){
				
				return "Task updation failed with given errors :-"+e;
			}
	}

		
		//Method For employee add/provision
		@Override
		public String addemp(String id, String n, String e, String p, String t, String r) {
	
			String pass = db.passwordEncoder().encode(p);
			
			String en="TRUE";
			try {
		        String i = "INSERT INTO SHIFT_EMP (RACF_ID,NAME,EMAIL,PASSWORD,PH,STATUS,ROLE)  VALUES (?, ?, ?, ?, ?, ?, ?)";
		        JT.update(i,id,n,e,pass,t,en,r);
		        return "Employee profile has been created with RACF_ID:->="+id+",Name "+n+"Email "+e+"who is assighned to ROLE: "+r;
		        
			} 
			catch (Exception e1){
			       
			        return "Please validate the details inserted and try again -Java Exception :- "+e1;
			        
			    }
		
		}

		//Method For update employee by admin
		@Override
		public String updateemp(String id,String n,String e,String p,String ph,String r,String en) {
			 
			emp oldemp = new emp();
			oldemp = searchonememp(id);
				
			if(n.equals(""))
				n=oldemp.getName();
			if(e.equals(""))
				e=oldemp.getEmail();
			if(ph.equals(""))
				ph=oldemp.getPh();
			if(r.equals(""))
				r=oldemp.getRole();
			if(en.equals(""))
					en=oldemp.getEn();
			
			String pass = db.passwordEncoder().encode(p);
			
			   String u = "UPDATE SHIFT_EMP SET NAME=? ,EMAIL=? ,PASSWORD=?, PH=?, ROLE=?, STATUS=? WHERE RACF_ID=?";
			   
			   try{
		        JT.update(u,n,e,pass,ph,r,en,id);
		     
		        return "Employee database has been updated for RACF_ID:-"+id+"Employee role is: -"+r;
			   }
			   catch( Exception e1){
				   return "Update task failed with given errors-."+e1;
			   }
			   
		}
			   
		
		//Method For get all employees
		@Override
		public List<emp> searchemp() {
			// 
			
			List <emp> L = new ArrayList<emp>();
			String sql_1 = "SELECT * FROM SHIFT_EMP";
			List<Map<String, Object>> rows1 = JT.queryForList(sql_1);
			for (Map row : rows1) {
				emp e=new emp();
				

				e.setRacfid((String)(row.get("RACF_ID")));
				e.setName((String)(row.get("NAME")));
				e.setEmail((String)(row.get("EMAIL")));
				e.setPh((String)(row.get("PH")));
				e.setRole((String)(row.get("ROLE")));
				
				L.add(e);
				}
			return L;
			
		
		}


		//Method For update employee by an employee
		@Override
		public String updateempbyemp(String id, String n, String e, String p, String ph) {

//			System.out.println(p+"INSIDE UPDATE EMP BY EMP "+pa);
			
			emp oldemp = new emp();
			oldemp = searchonememp(id);
				
			if(n.equals(""))
				n=oldemp.getName();
			if(e.equals(""))
				e=oldemp.getEmail();
			if(ph.equals(""))
				ph=oldemp.getPh();
			
			String pa = db.passwordEncoder().encode(p);
			
			   String u = "UPDATE SHIFT_EMP SET NAME=? ,EMAIL=? ,PASSWORD=? ,PH=? WHERE RACF_ID=?";
			  
			   try{
		        JT.update(u,n,e,pa,ph,id);
		        
		        return "Employee database has been updated for RACF_ID:-"+id;
			   }
			   catch( Exception e1){
				   return "Update task failed with given errors-."+e1;
			   }
			   
		}
		
		//Method to get a single employee data
		@Override
		public emp searchonememp(String racfid) {

			String sql = "SELECT * FROM SHIFT_EMP WHERE RACF_ID = '" + racfid+"'";
			   return  JT.query(sql, new ResultSetExtractor<emp>() {
			 
			        @Override
			        public emp extractData(ResultSet row) throws SQLException,DataAccessException {
			            if (row.next()) {
			            	emp T = new emp ();
							
							T.setRacfid(row.getString("RACF_ID"));
							T.setName(row.getString("NAME"));
							T.setEmail(row.getString("EMAIL"));
							T.setPassword(row.getString("PASSWORD"));
							T.setPh(row.getString("PH"));
							T.setEn(row.getString("STATUS"));
							T.setRole(row.getString("ROLE"));
							
			                return T;
			
			            }
			            return null;
			        }
			 
			    });
			}
		
		
		
}
		

	