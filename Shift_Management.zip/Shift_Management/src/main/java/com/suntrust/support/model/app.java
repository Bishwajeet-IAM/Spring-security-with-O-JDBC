package com.suntrust.support.model;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class app implements Serializable {
	
	private String appname;

	public String getAppname() {
		return appname;
	}

	public void setAppname(String appname) {
		this.appname = appname;
	}

	
	public app(){}
	public app(String a ){this.appname=a;}
}
