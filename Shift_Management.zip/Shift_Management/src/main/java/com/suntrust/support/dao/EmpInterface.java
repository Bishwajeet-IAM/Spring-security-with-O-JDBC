package com.suntrust.support.dao;
import com.suntrust.support.model.*;

import java.util.List;

import org.springframework.stereotype.Repository;

@Repository

public interface EmpInterface {

	
	public String Add (data m);
	public List<data> get_R (String s1,String s2,String s3);
	
	public String addtask (String ab,String a,String d);
	public task updatesearchtask (String id);
	public String updatetask (String id,String name,String u,String s);
	public List<task> searchtask (String id,String ab,String a,String s,String d);
	public String taskupdatebyadmin (String t,String d,String a);
	
	public emp searchonememp(String racfid);
	public List<emp> searchemp();
	public String addemp(String id,String n,String e,String p,String ph,String r);
	public String updateemp(String id,String n,String e,String p,String ph,String r,String en);
	public String updateempbyemp(String id,String n,String e,String p,String ph);
}
