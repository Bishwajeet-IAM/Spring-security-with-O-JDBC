package com.suntrust.support.dao;
import com.suntrust.support.model.*;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

@Repository

public interface EmpInterface {

	
	public String Add (data m);
	public List<data> searchshift (String s1,String s2,String s3,String s4);
	
	public String addtask (String ab,String a,String d,String p,String app,String env);
	public task updatesearchtask (String id);
	public String updatetask (String id,String name,String u,String s,String time,String ntim);
	public List<task> searchtask (String id,String ab,String a,String s,String d,String range,String p,String app,String env);
	public String taskupdatebyadmin (String t,String d,String ab,String a,String p,String app,String env);
	public List<task> searchend (String assignee,String dt);	
	public String bulktask (String tid,String ab,String a,String d, String pri,String app,String env);
	
	public emp searchonememp(String racfid);
	public List<emp> searchemp();
	public String addemp(String id,String n,String ln,String e,String p,String ph,String r);
	public String updateemp(String id,String n,String ln,String e,String p,String ph,String r,String en);
	public String updateempbyemp(String id,String n,String ln,String e,String p,String ph);
	
	public List<app> searchapp();
}
